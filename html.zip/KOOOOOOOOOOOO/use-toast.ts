"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import React from "react";
import { auth } from "@/lib/firebase";
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, FacebookAuthProvider } from "firebase/auth";
import { Icons } from "./icons";

const formSchema = z.object({
  email: z.string().email({ message: "الرجاء إدخال بريد إلكتروني صالح." }),
  password: z.string().min(6, { message: "يجب أن تكون كلمة المرور 6 أحرف على الأقل." }),
});

export function LoginForm() {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = React.useState(false);
  const [isFacebookLoading, setIsFacebookLoading] = React.useState(false);

  // Admin user email
  const adminEmail = "hmwdyalasbany34@gmail.com";

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, values.email, values.password);
      const user = userCredential.user;

      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: `مرحباً بك مرة أخرى، ${user.email}`,
      });

      // Special admin user check
      if (user.email === adminEmail) {
        router.push("/admin");
      } else {
        router.push("/dashboard");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      toast({
        title: "حدث خطأ",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  const handleSocialSignIn = async (provider: GoogleAuthProvider | FacebookAuthProvider) => {
      const isGoogle = provider instanceof GoogleAuthProvider;
      if (isGoogle) {
          setIsGoogleLoading(true);
      } else {
          setIsFacebookLoading(true);
      }

      try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;
        toast({
            title: "تم تسجيل الدخول بنجاح",
            description: `مرحباً بك، ${user.displayName}`,
        });
        // You might need to handle new user creation in Firestore here for social logins
        // if they don't exist yet.

        if (user.email === adminEmail) {
            router.push("/admin");
        } else {
            router.push("/dashboard");
        }
      } catch (error: any) {
         console.error("Social Sign-in error:", error);
         // Handle specific errors like account-exists-with-different-credential
         toast({
            title: "حدث خطأ",
            description: error.message,
            variant: "destructive",
        });
      } finally {
        if (isGoogle) {
            setIsGoogleLoading(false);
        } else {
            setIsFacebookLoading(false);
        }
      }
  }


  return (
    <div className="space-y-6">
       <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>البريد الإلكتروني</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="name@example.com" 
                    {...field} 
                    disabled={isLoading || isGoogleLoading || isFacebookLoading}
                    dir="ltr"
                    />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>كلمة المرور</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="********" 
                    {...field} 
                    disabled={isLoading || isGoogleLoading || isFacebookLoading}
                    dir="ltr"
                    />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full" disabled={isLoading || isGoogleLoading || isFacebookLoading}>
            {isLoading && <Loader2 className="ms-2 h-4 w-4 animate-spin" />}
            تسجيل الدخول
          </Button>
        </form>
      </Form>
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <Separator />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">
            أو سجل الدخول عبر
          </span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="outline" disabled={isLoading || isGoogleLoading || isFacebookLoading} onClick={() => handleSocialSignIn(new GoogleAuthProvider())}>
           {isGoogleLoading ? <Loader2 className="ms-2 h-4 w-4 animate-spin" /> : <Icons.google className="ms-2 h-4 w-4" />}
          Google
        </Button>
         <Button variant="outline" disabled={isLoading || isGoogleLoading || isFacebookLoading} onClick={() => handleSocialSignIn(new FacebookAuthProvider())}>
           {isFacebookLoading ? <Loader2 className="ms-2 h-4 w-4 animate-spin" /> : <Icons.facebook className="ms-2 h-4 w-4" />}
          Facebook
        </Button>
      </div>
    </div>
  );
}