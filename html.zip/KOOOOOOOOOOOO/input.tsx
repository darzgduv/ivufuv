import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.darz.wallet',
  appName: 'DAR Z',
  webDir: 'out',
  bundledWebRuntime: false,
  server: {
    // This is needed for local development with live-reload
    // Use your machine's IP address to test on a real device
    // url: 'http://192.168.1.10:3000', 
    cleartext: true
  }
};

export default config;
