import Link from 'next/link';
import { Logo } from '@/components/icons';
import { LoginForm } from '@/components/login-form';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
            <Link href="/" className="inline-block">
                <Logo className="h-12 w-auto mx-auto text-primary" />
            </Link>
          <h1 className="mt-6 text-3xl font-bold tracking-tight font-headline">
            تسجيل الدخول إلى حسابك
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            مرحباً بعودتك! الرجاء إدخال بياناتك للمتابعة.
          </p>
        </div>
        <LoginForm />
        <p className="mt-10 text-center text-sm text-muted-foreground">
          ليس لديك حساب؟{' '}
          <Link href="/signup" className="font-medium text-primary hover:underline">
            إنشاء حساب جديد
          </Link>
        </p>
      </div>
    </div>
  );
}