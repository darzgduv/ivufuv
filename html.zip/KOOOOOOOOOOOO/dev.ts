import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, initializeAuth, browserLocalPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  projectId: "al-sumaidee-wallet",
  appId: "1:28182065908:web:41c06580d4c14f382de4a1",
  storageBucket: "al-sumaidee-wallet.appspot.com",
  apiKey: "AIzaSyB-APw4TKr3nNyPUWNLVeGd-WAmO2_lJHw",
  authDomain: "al-sumaidee-wallet.firebaseapp.com",
  measurementId: "",
  messagingSenderId: "28182065908"
};


// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth with persistence
const auth = initializeAuth(app, {
    persistence: browserLocalPersistence
});

const db = getFirestore(app);

export { app, auth, db };