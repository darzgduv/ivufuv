import type { SVGProps } from 'react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M4 12h1.5a2.5 2.5 0 1 0 0-5H4" />
      <path d="M20 12h-1.5a2.5 2.5 0 1 1 0-5H20" />
      <path d="M4 8h16" />
      <path d="M4 16h16" />
      <path d="M12 4v16" />
    </svg>
  );
}

export const Icons = {
  btc: (props: SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M4.5 9.5H16c1.1 0 2.2.5 2.8 1.4 1 1.4.7 3.5-.7 4.6-1.1.8-2.5 1-3.8 1H7.5" />
      <path d="M9.5 17.5V7.5" />
      <path d="M13.5 17.5V7.5" />
      <path d="M9.5 13.5h4" />
    </svg>
  ),
  eth: (props: SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 2l6 7-6 7-6-7 6-7z" />
      <path d="M12 16l6 5-6 2-6-2 6-5z" />
      <path d="M12 16V2" />
      <path d="m6 9 6 7v8" />
      <path d="m18 9-6 7" />
    </svg>
  ),
  usdt: (props: SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 2v20" />
      <path d="M5 12h14" />
      <path d="M17 2H7c-2.8 0-5 2.2-5 5v0c0 2.8 2.2 5 5 5h0" />
    </svg>
  ),
  sol: (props: SVGProps<SVGSVGElement>) => (
    <svg
      role="img"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
      {...props}
    >
      <path d="m3.84 3.84 16.32 16.32M3.84 20.16 20.16 3.84M12.015 7.155a4.86 4.86 0 0 0-4.86 4.86 4.86 4.86 0 0 0 4.86 4.86 4.86 4.86 0 0 0 4.86-4.86 4.86 4.86 0 0 0-4.86-4.86Z" />
    </svg>
  ),
  doge: (props: SVGProps<SVGSVGElement>) => (
    <svg
      role="img"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
      {...props}
    >
      <path d="M12 24C5.372 24 0 18.628 0 12 0 5.373 5.372 0 12 0c6.627 0 12 5.373 12 12 0 6.628-5.373 12-12 12zm0-2.31c5.353 0 9.69-4.337 9.69-9.69S17.353 2.31 12 2.31 2.31 6.647 2.31 12c0 5.352 4.337 9.69 9.69 9.69z" />
      <path d="M11.517 6.132c-1.843.01-3.414.93-4.322 2.383l-.06.095-.008.01-.01.014c-.032.046-.06.09-.09.135l-.11.166-1.558 2.35.533.352.547.362 1.42-2.14.07-.107c.002-.002.003-.004.004-.006l.004-.006c.49-.69 1.253-1.11 2.11-1.127.31-.006.61.05.885.163l.115.047.075.033c.48.21.843.58 1.018 1.05v.003l.013.045c.01.036.015.07.02.106l.01.12c.002.09.002.18.002.27v4.613h-2.14V12.18h-1.07v4.746h-2.14V11.23c0-.02-.002-.04-.002-.06l0-.012v-.006a.09.09 0 0 1-.002-.01V9.414l-1.07-1.528v7.26h2.14v3.29h2.14v-3.29h1.07v-3.29h2.14v-1.643c0-.02 0-.04-.002-.06v-.102c0-.03-.005-.06-.008-.09l-.02-.12-.02-.12c-.06-.41-.2-.79-.42-1.12l-.023-.035c-.61-.9-1.6-1.48-2.73-1.55l-.11-.005.008-.002z" />
    </svg>
  ),
  shariaEarn: (props: SVGProps<SVGSVGElement>) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      {...props}
    >
        <path d="M12 2v2" />
        <path d="M12 20v2" />
        <path d="m4.93 4.93 1.41 1.41" />
        <path d="m17.66 17.66 1.41 1.41" />
        <path d="M2 12h2" />
        <path d="M20 12h2" />
        <path d="m6.34 17.66-1.41 1.41" />
        <path d="m19.07 4.93-1.41 1.41" />
        <circle cx="12" cy="12" r="4" />
        <path d="m12 18 3.5-3.5" />
        <path d="M12 6l-3.5 3.5" />
    </svg>
  ),
  earn: (props: SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <path d="M7 10V4.6a2 2 0 0 1 1.5-1.95 2 2 0 0 1 2.2.34L12 4l1.3-1.01a2 2 0 0 1 2.2-.34A2 2 0 0 1 17 4.6V10" />
        <path d="M2 10h20" />
    </svg>
  ),
  bnbCoin: (props: SVGProps<SVGSVGElement>) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M16.5 9.5 12 5l-4.5 4.5" />
        <path d="m12 19 4.5-4.5" />
        <path d="m7.5 14.5 4.5 4.5 4.5-4.5" />
        <path d="M12 5V.5" />
        <path d="m7.5 9.5-4 4" />
        <path d="m16.5 9.5 4 4" />
    </svg>
  ),
  google: (props: SVGProps<SVGSVGElement>) => (
    <svg
      role="img"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <title>Google</title>
      <path
        d="M12.48 10.92v3.28h7.84c-.24 1.84-.85 3.18-1.73 4.1-1.02 1.02-2.3 1.84-4.25 1.84-5.18 0-9.4-4.22-9.4-9.4s4.22-9.4 9.4-9.4c2.6 0 4.38 1.02 5.7 2.23l2.42-2.33C17.65.66 15.3 0 12.48 0 5.88 0 0 5.88 0 12.48s5.88 12.48 12.48 12.48c7.2 0 12.08-4.96 12.08-12.08 0-1.2-.12-2.32-.3-3.36z"
        fill="#FFFFFF"
      />
    </svg>
  ),
  facebook: (props: SVGProps<SVGSVGElement>) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      {...props}
      >
      <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
    </svg>
  ),
};