"use client";

import { MainNav } from "@/components/main-nav";
import { UserNav, SupportNav } from "@/components/user-nav";
import { Logo } from "@/components/icons";
import Link from "next/link";
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, loading, error] = useAuthState(auth);
  const router = useRouter();
  const [isRedirecting, setIsRedirecting] = useState(true);

  useEffect(() => {
    // If loading has finished
    if (!loading) {
      // And there's no user
      if (!user) {
        // Redirect to login page
        router.push('/login');
      } else {
        // If user is logged in, stop showing the loader
        setIsRedirecting(false);
      }
    }
  }, [user, loading, router]);

  // While firebase auth state is loading or we are waiting to redirect, show a loader
  if (loading || isRedirecting) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }
  
  // This should only be reached if the user is authenticated and we are not redirecting.
  // The check for user is an extra safeguard.
  if (user) {
    return (
      <div className="flex min-h-screen w-full flex-col">
        <header className="sticky top-0 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6 z-50">
          <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
            <Logo className="h-6 w-6 text-primary" />
            <span className="font-headline hidden md:inline-block">DAR Z</span>
          </Link>
          <div className="ms-auto flex items-center gap-4">
            <UserNav />
             <SupportNav />
          </div>
        </header>
        <div className="flex flex-1">
          <aside className="hidden border-s w-64 bg-background md:block">
              <MainNav />
          </aside>
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8 bg-secondary/20">
              {children}
          </main>
        </div>
      </div>
    );
  }

  // Fallback in case user is null but we are not loading or redirecting (should not happen)
  return null;
}
