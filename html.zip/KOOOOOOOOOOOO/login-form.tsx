"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Wallet,
  CandlestickChart,
  Users,
  Shield,
  LifeBuoy,
  BarChart2,
  MessageSquare,
} from "lucide-react";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "@/lib/firebase";

export function MainNav({
  className,
  ...props
}: React.HTMLAttributes<HTMLElement>) {
  const pathname = usePathname();
  const [user] = useAuthState(auth);

  // Check if the logged-in user is the admin
  const isAdmin = user?.email === "hmwdyalasbany34@gmail.com";
  
  const routes = [
    {
      href: "/dashboard",
      label: "لوحة التحكم",
      icon: LayoutDashboard,
      active: pathname === "/dashboard",
    },
    {
      href: "/wallet",
      label: "المحفظة",
      icon: Wallet,
      active: pathname.startsWith("/wallet"),
    },
    {
      href: "/markets",
      label: "الأسواق",
      icon: CandlestickChart,
      active: pathname.startsWith("/markets"),
    },
     {
      href: "/trading",
      label: "تداول",
      icon: BarChart2,
      active: pathname.startsWith("/trading"),
    },
    {
      href: "/p2p",
      label: "تداول P2P",
      icon: Users,
      active: pathname.startsWith("/p2p"),
    },
    {
      href: "/chat",
      label: "الرسائل",
      icon: MessageSquare,
      active: pathname.startsWith("/chat"),
    },
    {
      href: "/support",
      label: "الدعم الفني",
      icon: LifeBuoy,
      active: pathname.startsWith("/support"),
    },
  ];

  const adminRoutes = [
    {
      href: "/admin",
      label: "لوحة الإدارة",
      icon: Shield,
      active: pathname.startsWith("/admin"),
    },
  ];


  return (
    <nav
      className={cn("flex flex-col p-4 space-y-2", className)}
      {...props}
    >
      {routes.map((route) => (
        <Link
          key={route.href}
          href={route.href}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
            route.active && "bg-muted text-primary"
          )}
        >
          <route.icon className="h-4 w-4" />
          {route.label}
        </Link>
      ))}
      {isAdmin && (
        <>
            <div className="px-3 py-2">
                <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight font-headline">
                    الإدارة
                </h2>
            </div>
            {adminRoutes.map((route) => (
            <Link
                key={route.href}
                href={route.href}
                className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                route.active && "bg-muted text-primary"
                )}
            >
                <route.icon className="h-4 w-4" />
                {route.label}
            </Link>
            ))}
        </>
      )}
    </nav>
  );
}