"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/icons';
import { ArrowRight, CandlestickChart, Lock, Wallet } from 'lucide-react';
import Image from 'next/image';

export default function HomePage() {
  const flags = [
    { src: 'https://flagcdn.com/w40/iq.png', alt: 'Iraq Flag' },
    { src: 'https://flagcdn.com/w40/de.png', alt: 'Germany Flag' },
    { src: 'https://flagcdn.com/w40/us.png', alt: 'USA Flag' },
    { src: 'https://flagcdn.com/w40/sa.png', alt: 'Saudi Arabia Flag' },
    { src: 'https://flagcdn.com/w40/ae.png', alt: 'UAE Flag' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <Logo className="h-6 w-6 text-primary" />
            <span className="font-headline hidden md:inline-block">DAR Z</span>
          </Link>
          <div className="ms-auto flex items-center gap-2">
            <Button variant="ghost" asChild>
                <Link href="/login">تسجيل الدخول</Link>
            </Button>
            <Button asChild>
              <Link href="/signup">
                ابدأ الآن <ArrowRight className="me-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </header>
      
      {/* Hero Section */}
      <main className="flex-1">
        <section className="relative py-20 md:py-32">
           <div 
              className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
              style={{ backgroundImage: "url('https://placehold.co/1920x1080/0d0221/a855f7.png?text=.')" }}
              data-ai-hint="crypto background"
            ></div>
          <div className="container relative text-center">
            <h1 className="text-4xl md:text-7xl font-black font-headline tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-primary">
              DAR Z: بوابتك لعالم المال الرقمي
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
              منصة تداول آمنة وموثوقة في قلب الشرق الأوسط، مصممة لتمكينك من تحقيق أهدافك المالية بكل سهولة وثقة.
            </p>
             <p className="mt-4 text-xl text-muted-foreground">
                المؤسس: <span className="font-bold text-3xl text-primary">محمد مال الله الصميدعي</span>
             </p>
            <div className="mt-8 flex justify-center gap-4">
               <Button size="lg" asChild>
                 <Link href="/signup">
                    إنشاء حساب مجاني
                 </Link>
               </Button>
                <Button size="lg" variant="outline" asChild>
                 <Link href="/markets">
                    استكشف الأسواق
                 </Link>
               </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-secondary/20">
            <div className="container">
                <div className="text-center mb-12">
                     <h2 className="text-3xl font-bold font-headline">لماذا تختار DAR Z؟</h2>
                     <p className="text-muted-foreground mt-2">نقدم لك الأدوات التي تحتاجها للنجاح في عالم العملات الرقمية.</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                    <div className="flex flex-col items-center text-center p-6 border rounded-lg bg-card">
                        <div className="p-3 bg-primary/10 rounded-full mb-4">
                            <Lock className="h-8 w-8 text-primary" />
                        </div>
                        <h3 className="text-xl font-bold font-headline mb-2">أمان من الطراز العالمي</h3>
                        <p className="text-muted-foreground">نستخدم أحدث تقنيات التشفير لحماية أصولك وبياناتك على مدار الساعة.</p>
                    </div>
                     <div className="flex flex-col items-center text-center p-6 border rounded-lg bg-card">
                        <div className="p-3 bg-primary/10 rounded-full mb-4">
                            <CandlestickChart className="h-8 w-8 text-primary" />
                        </div>
                        <h3 className="text-xl font-bold font-headline mb-2">تجربة تداول متقدمة</h3>
                        <p className="text-muted-foreground">أدوات تحليل فني ورسوم بيانية مباشرة لمساعدتك على اتخاذ قرارات مستنيرة.</p>
                    </div>
                     <div className="flex flex-col items-center text-center p-6 border rounded-lg bg-card">
                        <div className="p-3 bg-primary/10 rounded-full mb-4">
                           <Wallet className="h-8 w-8 text-primary" />
                        </div>
                        <h3 className="text-xl font-bold font-headline mb-2">إيداع وسحب مرن</h3>
                        <p className="text-muted-foreground">خيارات متعددة للإيداع والسحب بما في ذلك التحويلات البنكية والمحافظ الرقمية.</p>
                    </div>
                </div>
            </div>
        </section>
      </main>

      {/* Footer */}
       <footer className="border-t">
        <div className="container flex flex-col items-center justify-between gap-6 py-10 text-center">
            <div className="flex justify-center gap-4">
              {flags.map((flag, index) => (
                <Image
                  key={index}
                  src={flag.src}
                  alt={flag.alt}
                  width={30}
                  height={20}
                  className="rounded-sm"
                  data-ai-hint="country flag"
                />
              ))}
            </div>
            <p className="text-sm text-muted-foreground">تم التأسيس سنة 2025</p>
            <p className="text-sm text-muted-foreground">
              جميع حقوق الطبع والنشر والتأسيس محفوظة لدى (<strong className="font-headline text-base">محمد مال الله الصميدعي</strong>).
            </p>
          </div>
      </footer>
    </div>
  );
}