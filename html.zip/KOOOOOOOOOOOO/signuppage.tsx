"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowUpRight, DollarSign, Wallet, ArrowRight, Activity, Users, AppWindow, Gift, MoreHorizontal, BarChart2, Loader2, Handshake } from "lucide-react";
import Link from "next/link";
import { Icons } from "@/components/icons";
import { Badge } from "@/components/ui/badge";
import { useAuthState } from 'react-firebase-hooks/auth';
import { useDocumentData } from 'react-firebase-hooks/firestore';
import { auth, db } from '@/lib/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from "@/hooks/use-toast";


const assets = [
    { name: "Bitcoin", code: "BTC", icon: Icons.btc, amount: "0.5000", value: "32,500.00", change: "+1.2%" },
    { name: "Ethereum", code: "ETH", icon: Icons.eth, amount: "10.200", value: "18,360.00", change: "-0.5%" },
    { name: "Tether", code: "USDT", icon: Icons.usdt, amount: "15,000.00", value: "15,000.00", change: "+0.1%" },
];

const recentActivity = [
    { type: "إيداع", asset: "BTC", amount: "0.1", status: "مكتمل", date: "2024-05-20" },
    { type: "تداول P2P", asset: "USDT", amount: "500", status: "مكتمل", date: "2024-05-19" },
    { type: "سحب", asset: "ETH", amount: "1.5", status: "قيد المعالجة", date: "2024-05-18" },
];


export default function DashboardPage() {
  const [user, authLoading] = useAuthState(auth);
  const [userData, dataLoading] = useDocumentData(user ? doc(db, 'users', user.uid) : null);
  const [loanAmount, setLoanAmount] = useState("");
  const [isLoanDialogOpen, setIsLoanDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleRequestLoan = () => {
    if (parseFloat(loanAmount) > 0) {
      setIsLoanDialogOpen(false);
      toast({
        title: "تم استلام طلبك بنجاح",
        description: "طلبك قيد المراجعة، سيتم إشعارك عند الموافقة.",
      });
      setLoanAmount("");
    } else {
      toast({
        title: "خطأ",
        description: "الرجاء إدخال مبلغ صحيح.",
        variant: "destructive",
      });
    }
  };

  const quickAccessItems = [
      { label: "تداول", icon: BarChart2, href: "/trading" },
      { label: "إحالة", icon: Users, href: "#" },
      { 
        label: "طلب قرض", 
        icon: Handshake, 
        href: "#",
        action: () => setIsLoanDialogOpen(true)
      },
      { label: "اكسب معنا", icon: Icons.shariaEarn, href: "#" },
      { label: "اربح BNB", icon: Icons.bnbCoin, href: "#" },
  ]

  const loading = authLoading || dataLoading;

  return (
    <>
      <div className="grid gap-4 md:gap-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي الرصيد</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {loading ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
              ) : (
                  <>
                      <div className="text-2xl font-bold font-headline">${(userData?.balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <p className="text-xs text-muted-foreground">+2.1% عن الشهر الماضي</p>
                  </>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardContent className="flex justify-around p-4">
              {quickAccessItems.map((item, index) => {
                  const content = (
                     <div key={index} className="flex flex-col items-center gap-2 text-center text-xs font-medium hover:text-primary transition-colors">
                       <div className="flex items-center justify-center w-12 h-12 bg-secondary rounded-full">
                         <item.icon className="h-6 w-6" />
                       </div>
                       <span>{item.label}</span>
                    </div>
                  );

                  if (item.action) {
                      return <button onClick={item.action} className="contents">{content}</button>;
                  }

                  return <Link href={item.href} key={index} className="contents">{content}</Link>;
              })}
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="lg:col-span-4">
            <CardHeader>
              <CardTitle>أصولي</CardTitle>
              <CardDescription>نظرة عامة على العملات الرقمية التي تملكها.</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                  <div className="flex justify-center items-center py-8"><Loader2 className="h-8 w-8 animate-spin" /></div>
              ) : (
                  <Table>
                  <TableHeader>
                      <TableRow>
                      <TableHead>الأصل</TableHead>
                      <TableHead className="text-right">الكمية</TableHead>
                      <TableHead className="text-right">القيمة (USD)</TableHead>
                      <TableHead className="text-right">تغير (24 ساعة)</TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {assets.map((asset) => (
                      <TableRow key={asset.code}>
                          <TableCell>
                          <div className="flex items-center gap-2">
                              <asset.icon className="h-6 w-6" />
                              <div>
                              <div className="font-medium">{asset.name}</div>
                              <div className="text-xs text-muted-foreground">{asset.code}</div>
                              </div>
                          </div>
                          </TableCell>
                          <TableCell className="text-right font-mono">{asset.amount}</TableCell>
                          <TableCell className="text-right font-mono">${asset.value}</TableCell>
                          <TableCell className={`text-right ${asset.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                          {asset.change}
                          </TableCell>
                      </TableRow>
                      ))}
                  </TableBody>
                  </Table>
              )}
            </CardContent>
          </Card>
          <Card className="lg:col-span-3">
            <CardHeader className="flex flex-row items-center">
              <div className="grid gap-2">
                <CardTitle>النشاط الأخير</CardTitle>
                <CardDescription>
                  آخر المعاملات التي قمت بها.
                </CardDescription>
              </div>
              <Button asChild size="sm" className="me-auto gap-1">
                <Link href="#">
                  عرض الكل
                  <ArrowUpRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="grid gap-4">
              {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center gap-4">
                      <div className="bg-muted p-2 rounded-lg">
                         <Activity className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div className="grid gap-1 flex-1">
                          <p className="text-sm font-medium leading-none">{activity.type} {activity.asset}</p>
                          <p className="text-sm text-muted-foreground">{activity.date}</p>
                      </div>
                      <div className="text-left">
                          <div className="font-medium font-mono">{activity.amount}</div>
                          <Badge variant={activity.status === "مكتمل" ? "default" : "secondary"} className={`${activity.status === "مكتمل" ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{activity.status}</Badge>
                      </div>
                  </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
      <Dialog open={isLoanDialogOpen} onOpenChange={setIsLoanDialogOpen}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>طلب قرض</DialogTitle>
                <DialogDescription>
                    أدخل المبلغ الذي ترغب في اقتراضه. ستتم مراجعة طلبك من قبل الإدارة.
                </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
                <div className="space-y-2">
                    <Label htmlFor="loan-amount">المبلغ المطلوب (USD)</Label>
                    <Input 
                      id="loan-amount" 
                      placeholder="e.g., 500" 
                      type="number" 
                      value={loanAmount} 
                      onChange={(e) => setLoanAmount(e.target.value)} 
                    />
                </div>
            </div>
             <DialogFooter>
                <Button type="submit" className="w-full" onClick={handleRequestLoan}>
                  إرسال الطلب
                </Button>
            </DialogFooter>
        </DialogContent>
    </Dialog>
    </>
  );
}