import Link from 'next/link';
import { Logo } from '@/components/icons';
import { SignupForm } from '@/components/signup-form';

export default function SignupPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Link href="/" className="inline-block">
            <Logo className="h-12 w-auto mx-auto text-primary" />
          </Link>
          <h1 className="mt-6 text-3xl font-bold tracking-tight font-headline">
            إنشاء حساب جديد
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            أدخل بياناتك لتبدأ رحلتك معنا.
          </p>
        </div>
        <SignupForm />
        <p className="mt-10 text-center text-sm text-muted-foreground">
          هل لديك حساب بالفعل؟{' '}
          <Link href="/login" className="font-medium text-primary hover:underline">
            تسجيل الدخول
          </Link>
        </p>
      </div>
    </div>
  );
}